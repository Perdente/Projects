function OutputName = Recognition(TestImage, m, A, Eigenfaces)
% Recognizing step....
%
% Description: This function compares two faces by projecting the images into facespace and 
% measuring the Euclidean distance between them.
%
% Argument:      TestImage              - Path of the input test image
%
%                m                      - (M*Nx1) Mean of the training
%                                         database, which is output of 'EigenfaceCore' function.
%
%                Eigenfaces             - (M*Nx(P-1)) Eigen vectors of the
%                                         covariance matrix of the training
%                                         database, which is output of 'EigenfaceCore' function.
%
%                A                      - (M*NxP) Matrix of centered image
%                                         vectors, which is output of 'EigenfaceCore' function.
% 
% Returns:       OutputName             - Name of the recognized image in the training database.
%
% See also: RESHAPE, STRCAT
               

%%%%%%%%%%%%%%%%%%%%%%%% Projecting centered image vectors into facespace
% All centered images are projected into facespace by multiplying in
% Eigenface basis's. Projected vector of each face will be its corresponding
% feature vector.

ProjectedImages = [];
Train_Number = size(Eigenfaces,2);
for i = 1 : Train_Number
    temp = Eigenfaces'*A(:,i); % Projection of centered images into facespace
    ProjectedImages = [ProjectedImages temp]; 
end

%%%%%%%%%%%%%%%%%%%%%%%% Extracting the PCA features from test image
InputImage = imread(TestImage);
temp = InputImage(:,:,1);

[irow, icol] = size(temp);
InImage = reshape(temp',irow*icol,1);
Difference = double(InImage)-m; % Centered test image
ProjectedTestImage = Eigenfaces'*Difference; % Test image feature vector

%%%%%%%%%%%%%%%%%%%%%%%% Calculating Euclidean distances 
% Euclidean distances between the projected test image and the projection
% of all centered training images are calculated. Test image is
% supposed to have minimum distance with its corresponding image in the
% training database.

Euc_dist = [];
for i = 1 : Train_Number
    q = ProjectedImages(:,i);
    temp = ( norm( ProjectedTestImage - q ) )^2;
    Euc_dist = [Euc_dist temp];
end

[Euc_dist_min , Recognized_index] = min(Euc_dist);
if(Euc_dist_min>4e+15)
    Recognized_index=0;
end

% a= Recognized_index
%result(a)
%Recognized_index=a;

%----------------------------------------------

conn = database.ODBCConnection('attendance','root','');
sqlquery = 'select * from student';
curs = exec(conn,sqlquery);
curs = fetch(curs);
curs.Data 
colnames = {'StdName', 'Subject_ID','Semester','Date','Status'};
% switch(Recognized_index)
%     case Recognized_index
        
         if(Recognized_index==0)
            display('the man is not in our database');
            
         elseif(Recognized_index==1)
            sql='UPDATE student SET Status="Present" WHERE StdName = "Monuar"';
            fetch(conn,sql);
            display('Monuar is present')
       
         
        
          elseif(Recognized_index==2)
            sql='UPDATE student SET Status="Present" WHERE StdName = "Rubel"';
            fetch(conn,sql);
            display('Rubel is present')
          
       
         elseif(Recognized_index==3)
            sql='UPDATE student SET Status="Present" WHERE StdName = "Partho"';
            fetch(conn,sql);
            display('Partha is present') 
         
       
         elseif(Recognized_index==4)
            sql='UPDATE student SET Status="Present" WHERE StdName = "Jahid"';
            fetch(conn,sql);
            display('Jahid is present') 
          
        
       
         elseif(Recognized_index==5)
            sql='UPDATE student SET Status="Present" WHERE StdName = "Sifat"';
            fetch(conn,sql);
            display('Sifat is present')
            
         elseif(Recognized_index==6)
            sql='UPDATE student SET Status="Present" WHERE StdName = "Montasir"';
            fetch(conn,sql);
            display('Montasir is present') 
            
         elseif(Recognized_index==7)
            sql='UPDATE student SET Status="Present" WHERE StdName = "AR Rony"';
            fetch(conn,sql);
            display('AR Rony is present')
            
         elseif(Recognized_index==8)
            sql='UPDATE student SET Status="Present" WHERE StdName = "Sreekanto"';
            fetch(conn,sql);
            display('Sreekanto is present')        
                    
         end   
        
 [OutputName] = strcat(int2str(Recognized_index),'.jpg');
 
